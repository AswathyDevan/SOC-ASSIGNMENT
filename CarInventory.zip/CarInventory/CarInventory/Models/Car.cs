﻿namespace CarInventory.Models
{
    public class Car
    {
        public long Id { get; set; }
        public string? Name { get; set; }
        public string? IsAvailable { get; set; }
    }
}

